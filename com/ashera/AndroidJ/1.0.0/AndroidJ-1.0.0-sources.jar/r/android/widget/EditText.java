//start - license
/*
 * Copyright (c) 2025 Ashera Cordova
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
//end - license
package r.android.widget;

import r.android.content.Context;
import r.android.content.res.ColorStateList;
import r.android.view.KeyEvent;

public class EditText extends TextView {

	public EditText(Context context) {
		super(null);
	}
	
	public EditText(com.ashera.widget.IWidget widget) {
		super(widget);
	}
	
	public EditText() {
		super(null);
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return false;
	}


	@Override
	public String getText() {
		throw new RuntimeException("cannot be called by view.");
	}

	@Override
	public int computeSize(float width) {
		throw new RuntimeException("cannot be called by view.");
	}

	@Override
	public int nativeMeasureWidth(Object uiView) {
		return 0;
	}

	@Override
	public int nativeMeasureHeight(Object uiView, int width) {
		return 0;
	}

}
