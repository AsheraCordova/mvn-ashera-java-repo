//start - license
/*
 * Copyright (c) 2025 Ashera Cordova
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
//end - license
package org.apache.cordova;

import java.io.StringReader;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import com.ashera.utils.FileUtils;

public class ConfigXmlUtils {
	public static XmlPullParser getConfigXml() {
		XmlPullParser parser;
		try {
			String xml = FileUtils.getFileFromClassPath("res/xml/config.xml");
//			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
//			factory.setNamespaceAware(true);
			parser = new org.xmlpull.mxp1.MXParser();
			parser.setInput(new StringReader(xml));
		} catch (XmlPullParserException e) {
			System.out.println(e.getMessage());
			 throw new RuntimeException(e);
		}
		return parser;
	}
}
