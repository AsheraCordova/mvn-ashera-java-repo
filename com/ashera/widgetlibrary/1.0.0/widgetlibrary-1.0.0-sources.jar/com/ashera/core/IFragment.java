//start - license
/*
 * Copyright (c) 2025 Ashera Cordova
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */
//end - license
package com.ashera.core;

import java.util.List;
import java.util.Map;

import com.ashera.css.StyleSheet;
import com.ashera.widget.IWidget;
import com.ashera.widget.bus.EventBus;

public interface IFragment {
	String getFragmentId();
	String getActionUrl();
	
	// lifecycle methods
	void onAttach(IActivity activity);
	void onDetach();
	void onCreate(Object... args);
	void onDestroy();
	void onResume();
	void onPause();
	void onCloseDialog(java.util.Map<String, String> eventData);
	Object onCreateView(boolean measure);
	IFragment getRootFragment();
	
	EventBus getEventBus();
	IWidget getRootWidget();
	boolean hasDevData(String key);
	Object getDevData(String key);
	IActivity getRootActivity();
	Object getArgumentsBundle();
	void setRootWidget(IWidget widget);
	void storeUserData(String varName, Object objValue);
	Object getUserData(String varName);
	
	void storeInTempCache(String varName, Object objValue);
	Object getFromTempCache(String varName);
	Object getParentForRootWidget();
	
	StyleSheet getStyleSheet();
	void setStyleSheet(StyleSheet styleSheet);
	boolean isViewLoaded();
	
	void setFrame(int x, int y, int width, int height);
	void remeasure();
	void disableRemeasure();
	void enableRemeasure();

	List<Object> getDisposables();
	void addDisposable(Object disposable);
	
	void addListener(IWidget widget, Object listener);
	<T> List<T> getListener(Class<T> type);
	<T> List<T> getListener(IWidget widget, Class<T> type);
	void removeListener(IWidget widget, Object listener);
	
	void addError(com.ashera.model.Error error);
	boolean hasErrors();
	void resizeWindow(int width, int height);
	
	String getInlineResource(String key);
	void setInlineResource(String key, String value, boolean append);
	IFragment getParent();
	String getUId();
	String getRootDirectory();
	String getNamespace();
	void sendEvent(String action, Map<String, String> extraData);
}
